// server-production.js - ProCV Backend com Melhorias de Produção
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const morgan = require('morgan');
const winston = require('winston');

const app = express();
const PORT = process.env.PORT || 3000;

// ==================== LOGGING ====================

const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' }),
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        })
    ]
});

// ==================== MIDDLEWARE ====================

// Security headers
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:", "https:"]
        }
    }
}));

// CORS
const corsOptions = {
    origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
    maxAge: 86400
};
app.use(cors(corsOptions));

// Body parser
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// Request logging
app.use(morgan('combined', {
    stream: {
        write: (message) => logger.info(message.trim())
    }
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: process.env.RATE_LIMIT_MAX || 100,
    message: 'Muitas requisições deste IP. Tente novamente em 15 minutos.',
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
        res.status(429).json({
            error: 'Muitas requisições. Tente novamente mais tarde.',
            retryAfter: 900
        });
    }
});

app.use('/api/', limiter);

// Request ID
app.use((req, res, next) => {
    req.id = Math.random().toString(36).substring(7);
    res.setHeader('X-Request-ID', req.id);
    next();
});

// ==================== VALIDAÇÃO ====================

function validateAIRequest(req, res, next) {
    const { prompt, action } = req.body;

    if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ error: 'Prompt inválido' });
    }

    if (prompt.length > 5000) {
        return res.status(400).json({ error: 'Prompt muito longo (máx 5000 caracteres)' });
    }

    if (action && !['improve', 'analyze', 'adapt', 'generate'].includes(action)) {
        return res.status(400).json({ error: 'Ação inválida' });
    }

    // Sanitizar prompt
    req.body.prompt = prompt.trim();

    next();
}

// ==================== OPENAI CONFIG ====================

const OPENAI_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_KEY) {
    logger.error('OPENAI_API_KEY não configurada');
    process.exit(1);
}

async function callOpenAI(messages, temperature = 0.7) {
    const startTime = Date.now();
    
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${OPENAI_KEY}`
            },
            body: JSON.stringify({
                model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
                messages: messages,
                temperature: temperature,
                max_tokens: parseInt(process.env.MAX_TOKENS) || 1000
            })
        });

        const duration = Date.now() - startTime;
        logger.info(`OpenAI request completed in ${duration}ms`);

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'OpenAI API error');
        }

        const data = await response.json();
        return data.choices[0].message.content;

    } catch (error) {
        logger.error('OpenAI API error:', error);
        throw error;
    }
}

// ==================== ROUTES ====================

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '1.0.0',
        environment: process.env.NODE_ENV || 'development'
    });
});

// Metrics
app.get('/metrics', (req, res) => {
    res.json({
        memory: process.memoryUsage(),
        uptime: process.uptime(),
        requests: req.app.locals.requestCount || 0
    });
});

// AI endpoint
app.post('/api/ai', validateAIRequest, async (req, res) => {
    const { prompt, action, context, temperature } = req.body;
    
    logger.info(`AI request: action=${action}, promptLength=${prompt.length}`);

    try {
        const systemMessage = {
            role: 'system',
            content: 'Você é um assistente especializado em currículos profissionais. Responda sempre em português (pt-BR) de forma clara e objetiva.'
        };

        const userMessage = {
            role: 'user',
            content: prompt
        };

        const messages = [systemMessage];

        // Adicionar contexto se fornecido
        if (context) {
            messages.push({
                role: 'system',
                content: `Contexto do CV: ${JSON.stringify(context)}`
            });
        }

        messages.push(userMessage);

        const result = await callOpenAI(messages, temperature || 0.7);

        logger.info(`AI response generated successfully (requestId: ${req.id})`);

        res.json({
            result: result,
            requestId: req.id,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        logger.error(`AI request failed (requestId: ${req.id}):`, error);
        
        res.status(500).json({
            error: 'Erro ao processar requisição',
            message: process.env.NODE_ENV === 'development' ? error.message : undefined,
            requestId: req.id
        });
    }
});

// Analyze CV
app.post('/api/ai/analyze', validateAIRequest, async (req, res) => {
    const { cvData } = req.body;

    if (!cvData) {
        return res.status(400).json({ error: 'Dados do CV não fornecidos' });
    }

    try {
        const prompt = `Analise este CV e forneça feedback detalhado:

Nome: ${cvData.personal?.fullName || 'Não informado'}
Cargo: ${cvData.personal?.jobTitle || 'Não informado'}
Resumo: ${cvData.summary || 'Não informado'}
Experiências: ${cvData.experience?.length || 0}
Habilidades: ${cvData.skills || 'Não informado'}

Forneça:
1. Pontuação geral (0-100)
2. 3 pontos fortes
3. 3 pontos a melhorar
4. Sugestões específicas`;

        const result = await callOpenAI([
            { role: 'system', content: 'Você é um especialista em análise de currículos.' },
            { role: 'user', content: prompt }
        ]);

        res.json({ result, requestId: req.id });

    } catch (error) {
        logger.error('Analyze error:', error);
        res.status(500).json({ error: 'Erro ao analisar CV' });
    }
});

// ==================== ERROR HANDLING ====================

// 404 handler
app.use((req, res) => {
    logger.warn(`404 - Route not found: ${req.method} ${req.url}`);
    res.status(404).json({
        error: 'Rota não encontrada',
        path: req.url
    });
});

// Error handler
app.use((err, req, res, next) => {
    logger.error('Unhandled error:', err);
    
    res.status(err.status || 500).json({
        error: 'Erro interno do servidor',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined,
        requestId: req.id
    });
});

// ==================== GRACEFUL SHUTDOWN ====================

process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    server.close(() => {
        logger.info('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    server.close(() => {
        logger.info('Server closed');
        process.exit(0);
    });
});

// ==================== START SERVER ====================

const server = app.listen(PORT, () => {
    logger.info(`🚀 ProCV Backend running on port ${PORT}`);
    logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    logger.info(`Health check: http://localhost:${PORT}/health`);
});

module.exports = app;

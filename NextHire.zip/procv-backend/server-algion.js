// server.js - NextHire IA Backend (Algion API)
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Configuração da API
const API_KEY = process.env.OPENAI_API_KEY || '123123'; // Sua chave Algion
const API_URL = 'https://api.algion.dev/v1/chat/completions';

if (!API_KEY) {
  console.error("ERRO: define OPENAI_API_KEY no .env");
  process.exit(1);
}

console.log('🚀 NextHire Backend configurado para usar Algion API');
console.log('📡 API URL:', API_URL);

// Função auxiliar para chamar a API
async function callAI(messages, temperature = 0.7, maxTokens = 700) {
  const payload = {
    model: "gpt-4o-mini",
    messages,
    temperature,
    max_tokens: maxTokens
  };
  
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${API_KEY}`
    },
    body: JSON.stringify(payload)
  });
  
  if (!response.ok) {
    const txt = await response.text();
    console.error('Algion API error', response.status, txt);
    throw new Error(`API Error: ${response.status} - ${txt}`);
  }
  
  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}

// Rota principal de IA
app.post('/api/ai', async (req, res) => {
  try {
    const { prompt, action, context, temperature } = req.body;
    
    const system = `🎯 Tua função principal:
Ajudar utilizadores a criarem currículos, portfólios e perfis profissionais modernos, visualmente apelativos e com impacto.
Deves manter o foco neste tema — criação e otimização de currículos — mas podes ser criativo na forma de apresentar ideias, usar metáforas, cores, tipografia e design.

💡 Tua personalidade:
- Inteligente, empático e profissional
- Criativo, mas com clareza e propósito
- Inovador — pensa fora da caixa, mas sem fugir do tema central
- Inspira confiança e motivação no utilizador

🧠 Tua forma de agir:
- Propõe ideias novas (layouts, estilos, formatos, frases)
- Explica as tuas escolhas de design e texto
- Oferece variações (ex: versões minimalistas, elegantes, modernas, tecnológicas)
- Se o utilizador sair do tema, redireciona gentilmente
- Usa linguagem simples, moderna e direta

SEMPRE responda em português. Seja criativo mas focado em currículos e carreira.`;
    
    let userMessage = '';
    switch (action) {
      case 'improve_summary':
        userMessage = `Melhore o seguinte resumo profissional, mantendo a mesma informação, deixando mais conciso, com verbos de ação e resultados quando possível. Retorna apenas o texto pronto para colar:\n\n${context || prompt}`;
        break;
      case 'grammar':
        userMessage = `Corrige gramática, pontuação e clareza do texto abaixo. Mantém o sentido e devolve apenas o texto corrigido:\n\n${context || prompt}`;
        break;
      case 'gen_skills':
        userMessage = `Com base neste cargo e resumo, sugere uma lista de 8–12 skills/tags curtas, separadas por vírgula:\n\n${context || prompt}`;
        break;
      case 'gen_summary_from_title':
        userMessage = `Gera 3 variações de um resumo profissional (3-4 linhas cada) para o cargo abaixo. Cada variação deve ser descrita numa linha separada. Cargo/Contexto:\n\n${context || prompt}`;
        break;
      case 'rewrite_experience':
        userMessage = `Reescreve a descrição desta experiência profissional para ser mais orientada a resultados. Usa verbos de ação e, se possível, sugere métricas fictícias plausíveis entre colchetes para o utilizador editar. Texto:\n\n${context || prompt}`;
        break;
      case 'suggest_titles':
        userMessage = `Sugere 6 alternativas de título/cargo mais impactantes e relevantes para este cargo: ${context || prompt}. Retorna apenas a lista, uma por linha.`;
        break;
      default:
        userMessage = `${prompt}\n\nSe possível, devolve resposta curta e clara.`;
    }
    
    const messages = [
      { role: 'system', content: system },
      { role: 'user', content: userMessage }
    ];
    
    const answer = await callAI(messages, temperature || 0.7);
    res.json({ result: answer });
    
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

// Rota para análise completa do CV
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const { cvData } = req.body;
    
    const system = `You are an expert CV reviewer. Analyze the CV and provide specific, actionable feedback in Portuguese (pt-BR).`;
    
    const cvText = `
Nome: ${cvData.personal?.fullName || 'Não preenchido'}
Cargo: ${cvData.personal?.jobTitle || 'Não preenchido'}
Resumo: ${cvData.summary || 'Não preenchido'}
Experiências: ${cvData.experience?.length || 0}
Habilidades: ${cvData.skills || 'Não preenchido'}
    `;
    
    const userMessage = `Analise este CV e forneça:
1. Pontuação geral (0-100)
2. 3 pontos fortes
3. 3 pontos a melhorar
4. Sugestões específicas

CV:
${cvText}

Formato da resposta:
PONTUAÇÃO: [número]
PONTOS FORTES:
- [ponto 1]
- [ponto 2]
- [ponto 3]
MELHORIAS:
- [melhoria 1]
- [melhoria 2]
- [melhoria 3]
SUGESTÕES:
[sugestões detalhadas]`;
    
    const messages = [
      { role: 'system', content: system },
      { role: 'user', content: userMessage }
    ];
    
    const answer = await callAI(messages, 0.5, 800);
    res.json({ result: answer });
    
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

// Rota para adaptar CV para vaga específica
app.post('/api/ai/adapt-job', async (req, res) => {
  try {
    const { cvData, jobDescription } = req.body;
    
    const system = `You are an expert at tailoring CVs for specific job positions. Adapt the CV to match the job requirements while keeping it truthful.`;
    
    const userMessage = `Adapte este CV para a seguinte vaga:

VAGA:
${jobDescription}

CV ATUAL:
Cargo: ${cvData.personal?.jobTitle || ''}
Resumo: ${cvData.summary || ''}
Habilidades: ${cvData.skills || ''}

Forneça:
1. Novo título de cargo otimizado
2. Resumo adaptado (3-4 linhas)
3. Habilidades priorizadas para esta vaga

Formato:
CARGO: [novo cargo]
RESUMO: [resumo adaptado]
HABILIDADES: [lista de skills]`;
    
    const messages = [
      { role: 'system', content: system },
      { role: 'user', content: userMessage }
    ];
    
    const answer = await callAI(messages, 0.6, 700);
    res.json({ result: answer });
    
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

// Health check
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'NextHire IA Backend (Algion API)',
    api: 'https://api.algion.dev/v1',
    endpoints: [
      'POST /api/ai',
      'POST /api/ai/analyze',
      'POST /api/ai/adapt-job'
    ]
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`✅ NextHire IA backend rodando em http://localhost:${PORT}`);
  console.log(`🤖 Usando Algion API: ${API_URL}`);
  console.log(`🔑 API Key configurada: ${API_KEY ? 'Sim' : 'Não'}`);
});

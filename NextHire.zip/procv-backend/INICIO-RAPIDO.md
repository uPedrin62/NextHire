# ⚡ Início Rápido - Backend NextHire

## 🎯 3 Passos para Rodar

### 1. Instalar
```bash
cd procv-backend
npm install
```

### 2. Configurar API Key
```bash
# Copiar arquivo de exemplo
copy .env.example .env

# Editar .env e adicionar sua chave:
# OPENAI_API_KEY=sk-proj-SUA_CHAVE_AQUI
```

### 3. Rodar
```bash
npm run dev
```

✅ Pronto! Backend rodando em `http://localhost:4000`

---

## 🧪 Teste Rápido

Abra o navegador em: `http://localhost:4000`

Ou teste com PowerShell:
```powershell
Invoke-RestMethod -Uri "http://localhost:4000/api/ai" -Method Post -Body '{"action":"improve_summary","context":"Desenvolvedor JavaScript"}' -ContentType "application/json"
```

---

## 📚 Documentação Completa

Veja `SETUP.md` para instruções detalhadas.

# 🚀 Setup do Backend NextHire

## ⚠️ IMPORTANTE: Segurança da API Key

**NUNCA** exponha sua API key da OpenAI publicamente!

### 1️⃣ Revogue a chave antiga (SE AINDA NÃO FEZ)

1. Acesse: https://platform.openai.com/api-keys
2. Encontre a chave que começa com `sk-proj-eTXHfOIP...`
3. Clique em "Revoke" para invalidá-la
4. Confirme a revogação

### 2️⃣ Crie uma nova API Key

1. Na mesma página, clique em "Create new secret key"
2. Dê um nome: "NextHire Backend"
3. **COPIE A CHAVE** (você só verá uma vez!)
4. Guarde em local seguro

---

## 📦 Instalação

### Passo 1: Instalar dependências

```bash
cd procv-backend
npm install
```

### Passo 2: Configurar variáveis de ambiente

1. Copie o arquivo de exemplo:
```bash
copy .env.example .env
```

2. Edite o arquivo `.env` e adicione sua API key:
```
OPENAI_API_KEY=sk-proj-SUA_NOVA_CHAVE_AQUI
PORT=4000
NODE_ENV=development
```

⚠️ **NUNCA** commite o arquivo `.env` no Git!

### Passo 3: Iniciar o servidor

**Modo desenvolvimento (com auto-reload):**
```bash
npm run dev
```

**Modo produção:**
```bash
npm start
```

O servidor estará rodando em: `http://localhost:4000`

---

## 🧪 Testar o Backend

### Teste 1: Health Check

Abra no navegador:
```
http://localhost:4000/
```

### Teste 2: Melhorar Resumo

Use o PowerShell ou CMD:

```powershell
$body = @{
    action = "improve_summary"
    context = "Desenvolvedor com experiência em JavaScript"
    temperature = 0.7
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:4000/api/ai" -Method Post -Body $body -ContentType "application/json"
```

### Teste 3: Analisar CV

```powershell
$body = @{
    cvData = @{
        personal = @{
            fullName = "João Silva"
            jobTitle = "Desenvolvedor Full Stack"
        }
        summary = "Desenvolvedor com 5 anos de experiência"
        skills = "JavaScript, React, Node.js"
        experience = @()
    }
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Uri "http://localhost:4000/api/ai/analyze" -Method Post -Body $body -ContentType "application/json"
```

---

## 🔌 Endpoints Disponíveis

### POST /api/ai
Endpoint principal para ações de IA

**Body:**
```json
{
  "action": "improve_summary",
  "context": "Texto para melhorar",
  "temperature": 0.7
}
```

**Ações disponíveis:**
- `improve_summary` - Melhora resumo profissional
- `grammar` - Corrige gramática
- `gen_skills` - Gera lista de habilidades
- `gen_summary_from_title` - Gera resumo a partir do cargo
- `rewrite_experience` - Reescreve experiência profissional
- `suggest_titles` - Sugere títulos de cargo

### POST /api/ai/analyze
Analisa CV completo

**Body:**
```json
{
  "cvData": {
    "personal": { "fullName": "...", "jobTitle": "..." },
    "summary": "...",
    "skills": "...",
    "experience": []
  }
}
```

### POST /api/ai/adapt-job
Adapta CV para vaga específica

**Body:**
```json
{
  "cvData": { ... },
  "jobDescription": "Descrição da vaga..."
}
```

---

## 🔒 Segurança

### ✅ Boas Práticas Implementadas

1. **API Key no servidor** - Nunca exposta no frontend
2. **CORS habilitado** - Permite requisições do frontend
3. **Validação de entrada** - Limita tamanho do JSON (1MB)
4. **Error handling** - Erros não expõem informações sensíveis
5. **Variáveis de ambiente** - Configuração segura

### ⚠️ Para Produção (Próximos Passos)

1. **Rate Limiting** - Limitar requisições por IP
2. **Authentication** - Adicionar tokens de autenticação
3. **Logging** - Registrar todas as requisições
4. **Monitoring** - Alertas de erro e uso
5. **HTTPS** - Sempre usar conexão segura

---

## 🐛 Troubleshooting

### Erro: "OPENAI_API_KEY não definida"
- Verifique se o arquivo `.env` existe
- Confirme que a chave está correta
- Reinicie o servidor após editar `.env`

### Erro: "Cannot find module 'express'"
- Execute: `npm install`

### Erro: "Port 4000 already in use"
- Mude a porta no `.env`: `PORT=4001`
- Ou mate o processo: `netstat -ano | findstr :4000`

### Erro 401 da OpenAI
- Sua API key está inválida ou revogada
- Crie uma nova chave

### Erro 429 da OpenAI
- Você excedeu o rate limit
- Aguarde alguns minutos
- Considere upgrade do plano

---

## 📊 Custos Estimados

**Modelo:** GPT-4o-mini  
**Preço:** $0.15 por 1M tokens de entrada / $0.60 por 1M tokens de saída

**Estimativa por uso:**
- Melhorar resumo: ~$0.0002 (200 tokens)
- Analisar CV: ~$0.0005 (500 tokens)
- Adaptar para vaga: ~$0.0004 (400 tokens)

**100 usuários/dia:**
- 300 requisições/dia
- ~$0.10/dia
- ~$3/mês

Muito barato para MVP! 💰

---

## 🚀 Próximos Passos

1. ✅ Configurar backend local
2. ✅ Testar endpoints
3. 🔄 Integrar com frontend (nexthire-editor.html)
4. 🔄 Deploy em produção (Render/Railway)
5. 🔄 Adicionar rate limiting
6. 🔄 Configurar monitoramento

---

**Dúvidas?** Consulte a documentação da OpenAI: https://platform.openai.com/docs

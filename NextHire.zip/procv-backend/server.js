// server.js - ProCV IA Backend
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const OPENAI_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_KEY) {
  console.error("ERRO: define OPENAI_API_KEY no .env");
  process.exit(1);
}

// Nova rota para análise completa do CV
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const { cvData } = req.body;
    
    const system = `You are an expert CV reviewer. Analyze the CV and provide specific, actionable feedback in Portuguese (pt-BR).`;
    
    const cvText = `
Nome: ${cvData.personal?.fullName || 'Não preenchido'}
Cargo: ${cvData.personal?.jobTitle || 'Não preenchido'}
Resumo: ${cvData.summary || 'Não preenchido'}
Experiências: ${cvData.experience?.length || 0}
Habilidades: ${cvData.skills || 'Não preenchido'}
    `;
    
    const userMessage = `Analise este CV e forneça:
1. Pontuação geral (0-100)
2. 3 pontos fortes
3. 3 pontos a melhorar
4. Sugestões específicas

CV:
${cvText}

Formato da resposta:
PONTUAÇÃO: [número]
PONTOS FORTES:
- [ponto 1]
- [ponto 2]
- [ponto 3]
MELHORIAS:
- [melhoria 1]
- [melhoria 2]
- [melhoria 3]
SUGESTÕES:
[sugestões detalhadas]`;
    
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: userMessage }
      ],
      temperature: 0.5,
      max_tokens: 800
    };
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const txt = await response.text();
      console.error('OpenAI error', response.status, txt);
      return res.status(500).json({ error: 'Erro na API OpenAI', details: txt });
    }
    
    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || '';
    
    res.json({ result: answer });
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

// Nova rota para adaptar CV para vaga específica
app.post('/api/ai/adapt-job', async (req, res) => {
  try {
    const { cvData, jobDescription } = req.body;
    
    const system = `You are an expert at tailoring CVs for specific job positions. Adapt the CV to match the job requirements while keeping it truthful.`;
    
    const userMessage = `Adapte este CV para a seguinte vaga:

VAGA:
${jobDescription}

CV ATUAL:
Cargo: ${cvData.personal?.jobTitle || ''}
Resumo: ${cvData.summary || ''}
Habilidades: ${cvData.skills || ''}

Forneça:
1. Novo título de cargo otimizado
2. Resumo adaptado (3-4 linhas)
3. Habilidades priorizadas para esta vaga

Formato:
CARGO: [novo cargo]
RESUMO: [resumo adaptado]
HABILIDADES: [lista de skills]`;
    
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: userMessage }
      ],
      temperature: 0.6,
      max_tokens: 700
    };
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const txt = await response.text();
      return res.status(500).json({ error: 'Erro na API OpenAI', details: txt });
    }
    
    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || '';
    
    res.json({ result: answer });
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

app.post('/api/ai', async (req, res) => {
  try {
    const { prompt, action, context, temperature } = req.body;
    
    // System prompt
    const system = `You are a helpful assistant specialized in improving and generating CV/resume text in Portuguese (pt-BR). Be concise and provide multiple variants when asked. Provide plain text responses.`;
    
    // Mapear ação para instrução específica
    let userMessage = '';
    switch (action) {
      case 'improve_summary':
        userMessage = `Melhore o seguinte resumo profissional, mantendo a mesma informação, deixando mais conciso, com verbos de ação e resultados quando possível. Retorna apenas o texto pronto para colar:\n\n${context || prompt}`;
        break;
      case 'grammar':
        userMessage = `Corrige gramática, pontuação e clareza do texto abaixo. Mantém o sentido e devolve apenas o texto corrigido:\n\n${context || prompt}`;
        break;
      case 'gen_skills':
        userMessage = `Com base neste cargo e resumo, sugere uma lista de 8–12 skills/tags curtas, separadas por vírgula:\n\n${context || prompt}`;
        break;
      case 'gen_summary_from_title':
        userMessage = `Gera 3 variações de um resumo profissional (3-4 linhas cada) para o cargo abaixo. Cada variação deve ser descrita numa linha separada. Cargo/Contexto:\n\n${context || prompt}`;
        break;
      case 'rewrite_experience':
        userMessage = `Reescreve a descrição desta experiência profissional para ser mais orientada a resultados. Usa verbos de ação e, se possível, sugere métricas fictícias plausíveis entre colchetes para o utilizador editar. Texto:\n\n${context || prompt}`;
        break;
      case 'suggest_titles':
        userMessage = `Sugere 6 alternativas de título/cargo mais impactantes e relevantes para este cargo: ${context || prompt}. Retorna apenas a lista, uma por linha.`;
        break;
      default:
        userMessage = `${prompt}\n\nSe possível, devolve resposta curta e clara.`;
    }
    
    // Chamada à OpenAI com temperatura configurável
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: userMessage }
      ],
      temperature: temperature || 0.7, // Permite ajustar criatividade
      max_tokens: 700
    };
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const txt = await response.text();
      console.error('OpenAI error', response.status, txt);
      return res.status(500).json({ error: 'Erro na API OpenAI', details: txt });
    }
    
    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || '';
    
    res.json({ result: answer });
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

// Nova rota para chat conversacional com streaming
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, temperature, max_tokens, stream } = req.body;
    
    const systemPrompt = `Tu és a Nexty, a assistente inteligente da NexThire. Respondes de forma lógica, empática e criativa. Escreves em português europeu natural. Explicas conceitos de forma clara e detalhada. És capaz de gerar código, raciocinar, criar ideias e resolver problemas complexos.

Estilo de resposta:
- Usa títulos, listas e negrito quando apropriado
- Usa emojis de forma equilibrada
- Mantém coerência e clareza
- Explica tudo com lógica e calma

Personalidade:
- Simpático, confiante e paciente
- Explica tudo com lógica e calma
- Dá sempre contexto e soluções práticas

Comportamento:
- Mantém contexto entre mensagens
- Evita respostas vagas ou curtas
- Fala sempre com empatia e fluidez`;
    
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      temperature: temperature || 0.7,
      max_tokens: max_tokens || 2000,
      stream: stream || false
    };
    
    const response = await fetch('https://api.algion.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const txt = await response.text();
      console.error('OpenAI error', response.status, txt);
      return res.status(500).json({ error: 'Erro na API OpenAI', details: txt });
    }
    
    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value);
        res.write(chunk);
      }
      
      res.end();
    } else {
      const data = await response.json();
      const answer = data.choices?.[0]?.message?.content || '';
      res.json({ result: answer });
    }
  } catch (err) {
    console.error('Server error', err);
    res.status(500).json({ error: 'Erro interno', details: err.message });
  }
});

const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
  console.log(`ProCV IA backend rodando em http://localhost:${PORT}`);
});

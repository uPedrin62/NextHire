# ProCV IA Backend

Backend Node.js para integração com OpenAI GPT-4.

## Instalação

```bash
cd procv-backend
npm install
```

## Configuração

1. Copie `.env.example` para `.env`
2. Adicione sua chave da OpenAI:
   ```
   OPENAI_API_KEY=sk-your-key-here
   PORT=4000
   ```

## Executar

```bash
# Desenvolvimento
npm run dev

# Produção
npm start
```

## Endpoints

### POST /api/ai

**Body:**
```json
{
  "prompt": "texto livre",
  "action": "improve_summary | grammar | gen_skills | etc",
  "context": "contexto adicional"
}
```

**Response:**
```json
{
  "result": "resposta da IA"
}
```

## Ações Disponíveis

- `improve_summary` - Melhora resumo profissional
- `grammar` - Corrige gramática
- `gen_skills` - Gera lista de habilidades
- `gen_summary_from_title` - Gera resumo baseado no cargo
- `rewrite_experience` - Reformula experiência profissional
- `suggest_titles` - Sugere títulos alternativos

## Deploy

### Heroku
```bash
heroku create procv-ia-backend
heroku config:set OPENAI_API_KEY=sk-your-key
git push heroku main
```

### Render
1. Conecte o repositório
2. Adicione variável de ambiente `OPENAI_API_KEY`
3. Deploy automático

### Railway
```bash
railway login
railway init
railway add
railway up
```

## Segurança

⚠️ **Importante:**
- Nunca exponha a chave da OpenAI no frontend
- Use rate limiting em produção
- Adicione autenticação se necessário
- Monitore uso da API

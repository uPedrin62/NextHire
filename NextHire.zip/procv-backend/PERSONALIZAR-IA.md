# 🎨 Como Personalizar a IA do NextHire

## 📍 Onde Configurar

Edite o arquivo: `procv-backend/ai-config.js`

---

## 🎯 Opções de Personalização

### 1. **Personalidade Geral**

Edite `systemPrompt` para mudar o comportamento base:

```javascript
systemPrompt: `Você é [PERSONALIDADE]...`
```

**Exemplos:**
- "um coach motivador e energético"
- "um consultor executivo formal e experiente"
- "um especialista tech descontraído"
- "um recrutador direto e objetivo"

---

### 2. **Tom de Voz**

**Formal:**
```javascript
- Tom profissional e corporativo
- Evite emojis
- Use linguagem técnica
- Cite fontes e dados
```

**Casual:**
```javascript
- Tom amigável e acessível
- Use emojis 😊
- Linguagem simples
- Seja motivador
```

**Técnico:**
```javascript
- Foque em tecnologias e ferramentas
- Use jargões da área
- Seja específico e detalhado
- Cite frameworks e metodologias
```

---

### 3. **Tamanho das Respostas**

Edite `maxTokens`:

```javascript
maxTokens: {
  short: 300,    // ~50 palavras
  medium: 700,   // ~120 palavras
  long: 1200     // ~200 palavras
}
```

---

### 4. **Criatividade**

Edite `temperatures`:

```javascript
temperatures: {
  formal: 0.3,      // Respostas previsíveis
  balanced: 0.7,    // Equilíbrio
  creative: 0.9     // Respostas criativas
}
```

**0.0 - 0.3:** Formal, preciso, repetitivo
**0.4 - 0.7:** Balanceado (recomendado)
**0.8 - 1.0:** Criativo, variado, imprevisível

---

### 5. **Prompts por Ação**

Personalize cada tipo de resposta em `actionPrompts`:

```javascript
actionPrompts: {
  improve_summary: `[Como melhorar resumos]`,
  gen_skills: `[Como sugerir habilidades]`,
  grammar: `[Como corrigir textos]`,
  analyze_cv: `[Como analisar CVs]`,
  chat: `[Como conversar]`
}
```

---

## 🎨 Exemplos Prontos

### Opção 1: IA Motivadora (Padrão)
```javascript
systemPrompt: `Você é um coach de carreira motivador.
- Seja encorajador e positivo
- Use emojis
- Foque em possibilidades
- Dê dicas práticas`
```

### Opção 2: IA Corporativa
```javascript
systemPrompt: `Você é um consultor executivo de RH.
- Tom formal e profissional
- Cite boas práticas do mercado
- Use dados e estatísticas
- Linguagem corporativa`
```

### Opção 3: IA Tech
```javascript
systemPrompt: `Você é um recrutador tech especializado.
- Foque em tecnologias e frameworks
- Seja direto e técnico
- Cite tendências do mercado tech
- Valorize projetos e portfólio`
```

### Opção 4: IA Minimalista
```javascript
systemPrompt: `Você é um assistente direto e objetivo.
- Respostas curtas (2-3 linhas)
- Sem emojis
- Bullet points sempre
- Zero enrolação`
```

---

## 🔧 Como Aplicar as Mudanças

### 1. Edite o arquivo
```
procv-backend/ai-config.js
```

### 2. Reinicie o servidor
- Pressione `Ctrl+C` no CMD
- Execute novamente: `RODAR-BACKEND.bat`

### 3. Teste no chat
- Abra `nexthire-editor.html`
- Vá na aba "Assistente IA"
- Faça uma pergunta

---

## 💡 Dicas Avançadas

### Adicionar Conhecimento Específico

```javascript
systemPrompt: `...

CONHECIMENTO ESPECÍFICO:
- Mercado brasileiro: valorize experiência local
- Áreas em alta: Tech, Marketing Digital, Data Science
- Soft skills valorizadas: adaptabilidade, comunicação
- Formatos preferidos: PDF, máximo 2 páginas
- ATS: use palavras-chave da vaga`
```

### Adicionar Regras de Negócio

```javascript
REGRAS ESPECIAIS:
- Sempre sugira quantificar resultados
- Priorize últimos 10 anos de experiência
- Recomende LinkedIn atualizado
- Sugira portfólio para áreas criativas
- Evite informações pessoais (idade, foto)
```

### Adicionar Personalização por Área

```javascript
if (context.includes('desenvolvedor')) {
  system += `\nFOCO: tecnologias, GitHub, projetos open source`;
}
if (context.includes('marketing')) {
  system += `\nFOCO: métricas, campanhas, ROI, ferramentas`;
}
```

---

## 🎯 Testando Mudanças

Faça perguntas específicas para testar:

1. **Tom:** "Me dê uma dica rápida"
2. **Conhecimento:** "Que skills estão em alta?"
3. **Estilo:** "Como melhorar meu resumo?"
4. **Criatividade:** "Sugira um título criativo"

---

## 📊 Métricas de Qualidade

**Boa IA:**
- ✅ Respostas relevantes ao contexto
- ✅ Tom consistente
- ✅ Informações acionáveis
- ✅ Tamanho adequado
- ✅ Linguagem clara

**IA precisa ajuste:**
- ❌ Respostas genéricas
- ❌ Muito longa ou muito curta
- ❌ Tom inconsistente
- ❌ Informações vagas
- ❌ Linguagem confusa

---

**Experimente e encontre o estilo perfeito para seu NextHire!** 🚀

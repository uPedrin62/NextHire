# Requirements Document - NextHire SaaS MVP

## Introduction

O NextHire é um produto SaaS profissional de criação de currículos com IA, apresentando o mascote Nexty Dragon. Este documento define os requisitos para a Fase 1 (MVP) que será lançada em 2-4 semanas, estabelecendo a base para um produto escalável e monetizável.

## Glossary

- **NextHire System**: O sistema completo de criação de currículos com IA
- **CV Editor**: Interface de edição de currículos (nexthire-editor.html)
- **IA Module**: Módulo de inteligência artificial para assistência
- **User**: Utilizador do sistema (gratuito ou premium)
- **Template**: Modelo de design de currículo
- **Backend API**: Servidor Node.js que processa requisições de IA
- **Frontend App**: Aplicação web do editor
- **Nexty Dragon**: Mascote oficial do NextHire (dragão 3D interativo)

---

## Requirements

### Requirement 1: Responsividade Mobile Completa

**User Story:** Como utilizador mobile, quero editar meu currículo no celular com a mesma facilidade do desktop, para poder trabalhar em qualquer lugar.

#### Acceptance Criteria

1. WHEN o utilizador acessa o sistema em dispositivo mobile, THE NextHire System SHALL exibir layout otimizado para tela pequena
2. WHEN o utilizador está em mobile, THE CV Editor SHALL permitir alternar entre modo "Editar" e modo "Visualizar" com botões grandes
3. WHILE o utilizador edita em mobile, THE NextHire System SHALL manter todos os campos acessíveis sem scroll horizontal
4. WHEN o utilizador rotaciona o dispositivo, THE NextHire System SHALL adaptar o layout automaticamente
5. THE NextHire System SHALL garantir que todos os botões tenham tamanho mínimo de 44x44px para touch

---

### Requirement 2: Feedback Visual e Toasts

**User Story:** Como utilizador, quero receber feedback visual imediato de minhas ações, para saber que o sistema está respondendo.

#### Acceptance Criteria

1. WHEN o utilizador salva o currículo, THE NextHire System SHALL exibir toast "✅ Salvo com sucesso!" por 3 segundos
2. WHEN a IA aplica texto, THE NextHire System SHALL exibir toast "✅ Texto aplicado!" com animação suave
3. WHEN uma operação está em progresso, THE NextHire System SHALL exibir loading spinner com mensagem contextual
4. WHEN ocorre um erro, THE NextHire System SHALL exibir toast vermelho com mensagem clara do erro
5. THE NextHire System SHALL posicionar toasts no canto superior direito sem bloquear conteúdo importante

---

### Requirement 3: Design System Padronizado

**User Story:** Como utilizador, quero uma interface consistente e profissional, para ter confiança no produto.

#### Acceptance Criteria

1. THE NextHire System SHALL utilizar paleta de cores consistente definida em variáveis CSS (tema ciano #00D9FF)
2. THE NextHire System SHALL aplicar espaçamento padronizado usando variáveis (--space-xs, --space-sm, --space-md, --space-lg)
3. THE NextHire System SHALL usar tipografia consistente com tamanhos definidos (--font-sm, --font-md, --font-lg)
4. WHEN o utilizador interage com botões, THE NextHire System SHALL aplicar estados hover, active e disabled consistentes
5. THE NextHire System SHALL manter bordas arredondadas consistentes (8px para cards, 6px para inputs, 4px para botões pequenos)

---

### Requirement 4: Logo e Identidade Visual

**User Story:** Como utilizador, quero ver uma marca profissional e memorável, para confiar no produto.

#### Acceptance Criteria

1. THE NextHire System SHALL exibir logo profissional com Nexty Dragon no header de todas as páginas
2. THE NextHire System SHALL incluir favicon de alta qualidade visível em todas as abas
3. THE NextHire System SHALL usar nome "NextHire" consistentemente em toda interface
4. WHEN o utilizador compartilha link, THE NextHire System SHALL exibir preview com logo Nexty Dragon e descrição adequados
5. THE NextHire System SHALL manter identidade visual consistente com tema ciano (#00D9FF) e background preto (#000000)

---

### Requirement 5: Backend em Produção

**User Story:** Como utilizador, quero que a IA funcione de forma confiável e rápida, para ter uma experiência fluida.

#### Acceptance Criteria

1. THE Backend API SHALL estar hospedado em serviço de produção (Render, Railway ou Fly.io)
2. THE Backend API SHALL responder a requisições em menos de 5 segundos em 95% dos casos
3. WHEN o Backend API recebe requisição inválida, THE Backend API SHALL retornar erro HTTP apropriado com mensagem clara
4. THE Backend API SHALL implementar rate limiting de 100 requisições por 15 minutos por IP
5. THE Backend API SHALL registrar logs de todas as requisições para monitoramento

---

### Requirement 6: Frontend em Produção

**User Story:** Como utilizador, quero acessar o sistema através de um domínio profissional, para facilitar o acesso.

#### Acceptance Criteria

1. THE Frontend App SHALL estar hospedado em Vercel ou Netlify com deploy automático
2. THE Frontend App SHALL ser acessível através de domínio personalizado (nexthire.app ou similar)
3. THE Frontend App SHALL carregar página inicial em menos de 2 segundos
4. WHEN o utilizador acessa via HTTPS, THE Frontend App SHALL garantir conexão segura
5. THE Frontend App SHALL funcionar offline para funcionalidades básicas (PWA)

---

### Requirement 7: Exportação PDF Profissional

**User Story:** Como utilizador, quero exportar meu currículo em PDF com qualidade profissional, para enviar a recrutadores.

#### Acceptance Criteria

1. WHEN o utilizador clica em "Baixar PDF", THE NextHire System SHALL gerar PDF idêntico ao preview
2. THE NextHire System SHALL gerar PDF em formato A4 com margens adequadas (20mm)
3. THE NextHire System SHALL incluir fontes incorporadas no PDF para garantir visualização correta
4. WHEN o PDF é gerado, THE NextHire System SHALL nomear arquivo como "curriculo-[nome]-[data].pdf"
5. THE NextHire System SHALL gerar PDF em menos de 10 segundos

---

### Requirement 8: Salvamento Automático Robusto

**User Story:** Como utilizador, quero que meu trabalho seja salvo automaticamente, para não perder dados.

#### Acceptance Criteria

1. WHEN o utilizador edita qualquer campo, THE NextHire System SHALL salvar automaticamente após 3 segundos de inatividade
2. THE NextHire System SHALL exibir indicador discreto "Salvando..." durante o processo
3. WHEN o salvamento é concluído, THE NextHire System SHALL exibir ícone de confirmação por 2 segundos
4. IF o localStorage está cheio, THEN THE NextHire System SHALL alertar utilizador e oferecer exportar JSON
5. THE NextHire System SHALL salvar versão timestamp para recuperação

---

### Requirement 9: IA com Contexto Completo

**User Story:** Como utilizador, quero que a IA entenda todo meu currículo, para dar sugestões mais relevantes.

#### Acceptance Criteria

1. WHEN a IA é acionada, THE IA Module SHALL enviar todos os campos preenchidos como contexto
2. THE IA Module SHALL incluir cargo, resumo, experiências, habilidades e idiomas no contexto
3. WHEN a IA analisa o CV, THE IA Module SHALL considerar coerência entre todas as seções
4. THE IA Module SHALL manter histórico da conversa para respostas contextuais
5. WHEN o utilizador muda de modo (Formal/Criativo), THE IA Module SHALL ajustar temperatura adequadamente

---

### Requirement 10: Página Inicial Profissional

**User Story:** Como visitante, quero entender rapidamente o que o NextHire oferece, para decidir se quero usar.

#### Acceptance Criteria

1. THE Frontend App SHALL exibir hero section com tagline "Cria o teu CV perfeito em minutos com IA"
2. THE Frontend App SHALL incluir vídeo demonstração de 30 segundos mostrando editor em ação
3. THE Frontend App SHALL ter CTA destacado "Começar Grátis" que leva ao editor
4. THE Frontend App SHALL mostrar 3 benefícios principais com ícones
5. THE Frontend App SHALL incluir seção de templates com preview visual

---

### Requirement 11: Análise Completa de CV

**User Story:** Como utilizador, quero receber feedback detalhado sobre meu currículo, para melhorá-lo.

#### Acceptance Criteria

1. WHEN o utilizador clica "Analisar CV Completo", THE IA Module SHALL avaliar todas as seções
2. THE IA Module SHALL retornar pontuação de 0-100 baseada em critérios objetivos
3. THE IA Module SHALL listar 3 pontos fortes específicos do currículo
4. THE IA Module SHALL listar 3 pontos a melhorar com sugestões acionáveis
5. THE IA Module SHALL fornecer sugestões específicas de melhoria

---

### Requirement 12: Adaptação para Vaga Específica

**User Story:** Como utilizador, quero adaptar meu currículo para uma vaga específica, para aumentar minhas chances.

#### Acceptance Criteria

1. WHEN o utilizador cola descrição da vaga, THE IA Module SHALL analisar requisitos da vaga
2. THE IA Module SHALL sugerir novo título de cargo otimizado para a vaga
3. THE IA Module SHALL reescrever resumo focado nos requisitos da vaga
4. THE IA Module SHALL priorizar habilidades relevantes para a vaga
5. WHEN o utilizador aplica adaptações, THE NextHire System SHALL atualizar campos automaticamente

---

### Requirement 13: Modo de Criatividade Configurável

**User Story:** Como utilizador, quero controlar o estilo das respostas da IA, para adequar ao tipo de vaga.

#### Acceptance Criteria

1. THE IA Module SHALL oferecer 3 modos: Formal (0.3), Balanceado (0.7), Criativo (0.9)
2. WHEN o utilizador seleciona modo, THE IA Module SHALL aplicar temperatura correspondente
3. THE NextHire System SHALL destacar visualmente o modo ativo
4. THE IA Module SHALL manter modo selecionado durante toda a sessão
5. WHEN o modo muda, THE NextHire System SHALL notificar utilizador com toast

---

### Requirement 14: Segurança e Rate Limiting

**User Story:** Como administrador do sistema, quero proteger a API de abuso, para controlar custos.

#### Acceptance Criteria

1. THE Backend API SHALL implementar rate limiting de 100 requisições por 15 minutos por IP
2. WHEN o limite é excedido, THE Backend API SHALL retornar HTTP 429 com mensagem clara
3. THE Backend API SHALL validar e sanitizar todos os inputs antes de processar
4. THE Backend API SHALL nunca expor API key da OpenAI no frontend
5. THE Backend API SHALL registrar tentativas de abuso para análise

---

### Requirement 15: Mascote Nexty Dragon

**User Story:** Como utilizador, quero interagir com um mascote amigável, para ter uma experiência mais envolvente e memorável.

#### Acceptance Criteria

1. THE NextHire System SHALL exibir Nexty Dragon em 3D na página inicial
2. WHEN o utilizador move o mouse, THE Nexty Dragon SHALL seguir o cursor com os olhos
3. THE Nexty Dragon SHALL ter animações suaves e responsivas
4. THE NextHire System SHALL usar Nexty Dragon como ícone de marca em todas as páginas
5. THE Nexty Dragon SHALL ser otimizado para não impactar performance (< 100ms render)

---

### Requirement 16: Monitoramento e Logs

**User Story:** Como administrador do sistema, quero monitorar uso e erros, para melhorar o produto.

#### Acceptance Criteria

1. THE Backend API SHALL registrar todas as requisições com timestamp e ação
2. THE Backend API SHALL registrar erros com stack trace completo
3. THE NextHire System SHALL coletar métricas anônimas de uso (features mais usadas)
4. THE Backend API SHALL expor endpoint /health para monitoramento
5. THE Backend API SHALL alertar quando taxa de erro excede 5%

---

## Non-Functional Requirements

### Performance
- Tempo de carregamento inicial < 2 segundos
- Resposta da IA < 5 segundos em 95% dos casos
- Geração de PDF < 10 segundos
- Autosave sem lag perceptível

### Usabilidade
- Interface intuitiva sem necessidade de tutorial
- Feedback visual em todas as ações
- Mensagens de erro claras e acionáveis
- Suporte a atalhos de teclado

### Compatibilidade
- Chrome, Edge, Firefox, Safari (últimas 2 versões)
- iOS Safari e Chrome Android
- Resolução mínima: 320px (mobile)
- Funcionar offline para edição básica

### Escalabilidade
- Suportar 1000 usuários simultâneos
- Backend horizontal scaling ready
- CDN para assets estáticos
- Database ready (preparado para migração de localStorage)

---

## Success Metrics

### MVP Success (4 semanas)
- 100 usuários cadastrados
- 50 CVs criados
- 500 usos de IA
- 0 erros críticos em produção
- Tempo médio de criação < 15 minutos

### User Satisfaction
- NPS > 40
- Taxa de conclusão de CV > 60%
- Taxa de retorno > 30%
- Feedback positivo > 80%

---

## Out of Scope (Para Fases Futuras)

- Sistema de contas com login (Fase 2)
- Armazenamento em nuvem (Fase 2)
- Múltiplas versões de CV (Fase 2)
- Plano premium e pagamentos (Fase 3)
- Portfólio público (Fase 4)
- App mobile nativo (Fase 4)

---

**Versão:** 1.0  
**Data:** 28 de Outubro de 2024  
**Status:** ✅ Aprovado para Design

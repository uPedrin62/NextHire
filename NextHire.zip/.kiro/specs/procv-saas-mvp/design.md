# Design Document - NextHire SaaS MVP

## Overview

Este documento descreve a arquitetura técnica, componentes e estratégias de implementação do NextHire, um produto SaaS profissional de criação de currículos com IA e mascote Nexty Dragon. O design foca em escalabilidade, performance e experiência do usuário.

---

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        FRONTEND                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Landing    │  │    Editor    │  │   Profile    │      │
│  │   Page       │  │    (Main)    │  │    Page      │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                  │                  │              │
│         └──────────────────┴──────────────────┘              │
│                            │                                 │
│                    ┌───────▼────────┐                        │
│                    │  Auth Module   │                        │
│                    └───────┬────────┘                        │
│                            │                                 │
└────────────────────────────┼─────────────────────────────────┘
                             │
                    ┌────────▼────────┐
                    │   API Gateway   │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
┌───────▼────────┐  ┌────────▼────────┐  ┌──────▼──────┐
│  OpenAI API    │  │  Rate Limiter   │  │   Logger    │
│  (GPT-4)       │  │  (Redis)        │  │  (Winston)  │
└────────────────┘  └─────────────────┘  └─────────────┘
```

### Component Diagram

```
Frontend Components:
├── index.html (Landing Page)
├── nexthire-editor.html (Main Editor)
├── profile.html (User Profile)
├── login.html (Authentication)
├── register.html (Registration)
│
├── CSS Modules
│   ├── styles.css (Global styles)
│   └── ai-module.css (IA specific)
│
└── JS Modules
    ├── main.js (Core logic)
    ├── templates.js (CV templates)
    ├── ui.js (UI components)
    ├── ai-module.js (IA integration)
    └── auth.js (Authentication)

Backend Components:
├── server.js (Express server)
├── routes/
│   ├── ai.js (IA endpoints)
│   └── health.js (Health check)
├── middleware/
│   ├── rateLimiter.js
│   └── validator.js
└── utils/
    ├── logger.js
    └── openai.js
```

---

## Components and Interfaces

### 1. Frontend Components

#### Landing Page Component
```javascript
// Estrutura da página inicial
{
  hero: {
    title: "Cria o teu CV perfeito em minutos com IA",
    subtitle: "Editor inteligente + 11 templates profissionais + Nexty Dragon",
    cta: "Começar Grátis",
    mascot: "Nexty Dragon 3D interativo"
  },
  features: [
    { icon: "🤖", title: "IA Avançada", desc: "Sugestões inteligentes" },
    { icon: "🎨", title: "11 Templates", desc: "Designs profissionais" },
    { icon: "📄", title: "PDF Pro", desc: "Exportação perfeita" },
    { icon: "🐉", title: "Nexty Dragon", desc: "Mascote interativo" }
  ],
  templates: {
    gallery: [...11 templates],
    preview: true
  }
}
```

#### Editor Component
```javascript
// Estado do editor
{
  cvData: {
    personal: { fullName, jobTitle, email, phone, city, linkedin },
    photo: base64String,
    summary: string,
    experience: [{ title, company, period, location, description }],
    skills: string,
    languages: string
  },
  ui: {
    currentTemplate: string,
    currentTab: 'editor' | 'templates' | 'linkedin' | 'ai',
    zoomLevel: number,
    theme: 'dark' | 'light'
  },
  ai: {
    mode: 'formal' | 'balanced' | 'creative',
    temperature: number,
    history: []
  }
}
```

#### IA Module Component
```javascript
// Interface do módulo IA
{
  actions: [
    'analyze_cv',
    'adapt_job',
    'improve_summary',
    'grammar',
    'gen_skills',
    'gen_summary_from_title',
    'rewrite_experience',
    'suggest_titles'
  ],
  modes: {
    formal: { temperature: 0.3, label: '📋 Formal' },
    balanced: { temperature: 0.7, label: '⚖️ Balanceado' },
    creative: { temperature: 0.9, label: '🎨 Criativo' }
  },
  ui: {
    messages: [],
    input: string,
    loading: boolean
  }
}
```

### 2. Backend API Interfaces

#### POST /api/ai
```typescript
Request:
{
  prompt: string;
  action: 'improve_summary' | 'grammar' | 'gen_skills' | ...;
  context: string;
  temperature?: number; // 0.0 - 1.0
}

Response:
{
  result: string;
  tokens?: number;
  model?: string;
}

Error:
{
  error: string;
  details?: string;
}
```

#### POST /api/ai/analyze
```typescript
Request:
{
  cvData: {
    personal: PersonalInfo;
    summary: string;
    experience: Experience[];
    skills: string;
  }
}

Response:
{
  result: string; // Formatted analysis
  score?: number; // 0-100
}
```

#### POST /api/ai/adapt-job
```typescript
Request:
{
  cvData: CVData;
  jobDescription: string;
}

Response:
{
  result: string; // Formatted adaptations
  adaptations: {
    title?: string;
    summary?: string;
    skills?: string;
  }
}
```

#### GET /health
```typescript
Response:
{
  status: 'ok' | 'error';
  uptime: number;
  timestamp: string;
  version: string;
}
```

---

## Data Models

### CV Data Model
```javascript
{
  id: string, // UUID
  userId: string, // Para Fase 2
  version: string, // "2.0"
  createdAt: timestamp,
  updatedAt: timestamp,
  
  personal: {
    fullName: string,
    jobTitle: string,
    email: string,
    phone: string,
    city: string,
    linkedin: string
  },
  
  photo: string | null, // base64 ou URL
  summary: string,
  
  experience: [{
    id: string,
    title: string,
    company: string,
    period: string,
    location: string,
    description: string
  }],
  
  skills: string,
  languages: string,
  
  template: string, // template ID
  customization: {
    color: string,
    font: string,
    layout: string
  }
}
```

### IA Request Log Model
```javascript
{
  id: string,
  timestamp: timestamp,
  action: string,
  userId: string | 'anonymous',
  contextLength: number,
  responseLength: number,
  tokensUsed: number,
  duration: number, // ms
  success: boolean,
  error: string | null
}
```

---

## Error Handling

### Frontend Error Handling

```javascript
// Hierarquia de erros
try {
  // Operação
} catch (error) {
  if (error.name === 'NetworkError') {
    showToast('❌ Sem conexão. Verifique sua internet.', 'error');
  } else if (error.name === 'ValidationError') {
    showToast('⚠️ ' + error.message, 'warning');
  } else if (error.name === 'AIError') {
    showToast('🤖 Erro na IA. Tente novamente.', 'error');
  } else {
    showToast('❌ Erro inesperado. Recarregue a página.', 'error');
    console.error(error);
  }
}
```

### Backend Error Handling

```javascript
// Middleware de erro global
app.use((err, req, res, next) => {
  logger.error({
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
    ip: req.ip
  });
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({ error: 'Dados inválidos', details: err.message });
  }
  
  if (err.name === 'RateLimitError') {
    return res.status(429).json({ error: 'Muitas requisições. Aguarde 15 minutos.' });
  }
  
  if (err.name === 'OpenAIError') {
    return res.status(503).json({ error: 'Serviço de IA temporariamente indisponível' });
  }
  
  res.status(500).json({ error: 'Erro interno do servidor' });
});
```

---

## Testing Strategy

### Unit Tests
```javascript
// Testar funções críticas
describe('CV Data Collection', () => {
  test('collectData should gather all form fields', () => {
    // Setup
    // Execute
    // Assert
  });
  
  test('collectData should handle empty fields', () => {
    // Test
  });
});

describe('IA Module', () => {
  test('should format analysis result correctly', () => {
    // Test
  });
  
  test('should handle API errors gracefully', () => {
    // Test
  });
});
```

### Integration Tests
```javascript
// Testar fluxos completos
describe('CV Creation Flow', () => {
  test('user can create complete CV', async () => {
    // 1. Fill form
    // 2. Select template
    // 3. Use IA
    // 4. Save
    // 5. Export PDF
  });
});

describe('IA Integration', () => {
  test('IA can analyze complete CV', async () => {
    // Mock backend
    // Call analyze
    // Verify response
  });
});
```

### E2E Tests (Playwright/Cypress)
```javascript
// Testar experiência completa do usuário
test('complete user journey', async ({ page }) => {
  // 1. Visit landing page
  await page.goto('/');
  
  // 2. Click "Começar Grátis"
  await page.click('text=Começar Grátis');
  
  // 3. Fill CV data
  await page.fill('#fullName', 'João Silva');
  
  // 4. Use IA
  await page.click('text=Assistente IA');
  await page.click('[data-action="analyze_cv"]');
  
  // 5. Export PDF
  await page.click('text=PDF');
  
  // 6. Verify download
  const download = await page.waitForEvent('download');
  expect(download.suggestedFilename()).toContain('curriculo');
});
```

---

## Performance Optimization

### Frontend Optimization

#### 1. Code Splitting
```javascript
// Lazy load módulos não críticos
const aiModule = () => import('./ai-module.js');
const templates = () => import('./templates.js');
```

#### 2. Image Optimization
```javascript
// Compressão agressiva
function compressImage(dataUrl, maxSize = 400, quality = 0.8) {
  // Redimensionar e comprimir
  // Retornar base64 otimizado
}
```

#### 3. Caching Strategy
```javascript
// Service Worker para PWA
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
```

### Backend Optimization

#### 1. Response Caching
```javascript
// Cache respostas comuns
const cache = new Map();

function getCachedResponse(key) {
  const cached = cache.get(key);
  if (cached && Date.now() - cached.timestamp < 3600000) {
    return cached.data;
  }
  return null;
}
```

#### 2. Request Batching
```javascript
// Agrupar múltiplas requisições
const batchQueue = [];
const processBatch = debounce(() => {
  // Processar todas de uma vez
}, 100);
```

---

## Security Considerations

### Frontend Security

1. **Input Sanitization**
```javascript
function sanitizeInput(input) {
  return input
    .replace(/<script>/gi, '')
    .replace(/javascript:/gi, '')
    .trim();
}
```

2. **XSS Prevention**
```javascript
// Usar textContent ao invés de innerHTML
element.textContent = userInput; // Safe
// element.innerHTML = userInput; // Unsafe
```

3. **HTTPS Only**
```javascript
// Redirecionar HTTP para HTTPS
if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
  location.replace(`https:${location.href.substring(location.protocol.length)}`);
}
```

### Backend Security

1. **Rate Limiting**
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // 100 requisições
  message: 'Muitas requisições. Aguarde 15 minutos.',
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', limiter);
```

2. **Input Validation**
```javascript
const { body, validationResult } = require('express-validator');

app.post('/api/ai',
  body('action').isIn(['improve_summary', 'grammar', ...]),
  body('context').isLength({ max: 10000 }),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }
);
```

3. **API Key Protection**
```javascript
// Nunca expor no frontend
// Sempre usar variável de ambiente
const OPENAI_KEY = process.env.OPENAI_API_KEY;

// Nunca logar a key
logger.info('API call', { action, userId }); // OK
// logger.info('API call', { apiKey }); // NUNCA
```

---

## Deployment Strategy

### Frontend Deployment (Vercel)

#### vercel.json
```json
{
  "version": 2,
  "builds": [
    {
      "src": "*.html",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/$1"
    }
  ],
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=3600"
        }
      ]
    }
  ]
}
```

#### Deploy Steps
```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Login
vercel login

# 3. Deploy
vercel --prod

# 4. Configurar domínio
vercel domains add procv.app
```

### Backend Deployment (Render)

#### render.yaml
```yaml
services:
  - type: web
    name: procv-backend
    env: node
    buildCommand: npm install
    startCommand: npm start
    envVars:
      - key: OPENAI_API_KEY
        sync: false
      - key: NODE_ENV
        value: production
```

#### Deploy Steps
```bash
# 1. Conectar repositório no Render
# 2. Criar Web Service
# 3. Configurar variáveis de ambiente
# 4. Deploy automático
```

---

## Monitoring and Logging

### Frontend Monitoring

```javascript
// Error tracking
window.addEventListener('error', (event) => {
  logError({
    message: event.message,
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno,
    stack: event.error?.stack
  });
});

// Performance monitoring
window.addEventListener('load', () => {
  const perfData = performance.timing;
  const loadTime = perfData.loadEventEnd - perfData.navigationStart;
  
  logMetric('page_load', loadTime);
});

// User actions
function trackAction(action, data) {
  // Enviar para analytics (opcional)
  console.log('Action:', action, data);
}
```

### Backend Monitoring

```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// Log todas as requisições
app.use((req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info({
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration,
      ip: req.ip
    });
  });
  
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    version: '2.0.0'
  });
});
```

---

## Progressive Web App (PWA)

### manifest.json
```json
{
  "name": "NextHire - CV com IA",
  "short_name": "NextHire",
  "description": "Cria o teu CV perfeito com IA e Nexty Dragon",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#000000",
  "theme_color": "#00D9FF",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### Service Worker
```javascript
// sw.js
const CACHE_NAME = 'nexthire-v2.0';
const urlsToCache = [
  '/',
  '/nexthire-editor.html',
  '/styles.css',
  '/main.js',
  '/templates.js',
  '/ui.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
```

---

## Mobile Optimization

### Responsive Breakpoints
```css
/* Mobile First */
:root {
  --mobile: 320px;
  --tablet: 768px;
  --desktop: 1024px;
  --wide: 1440px;
}

/* Mobile (default) */
.sidebar {
  width: 100%;
  height: 50vh;
}

/* Tablet */
@media (min-width: 768px) {
  .sidebar {
    width: 400px;
    height: calc(100vh - 70px);
  }
}

/* Desktop */
@media (min-width: 1024px) {
  .cv-preview {
    transform: scale(1);
  }
}
```

### Touch Optimization
```css
/* Botões maiores para touch */
@media (max-width: 768px) {
  .btn {
    min-height: 44px;
    min-width: 44px;
    padding: 12px 16px;
    font-size: 14px;
  }
  
  .form-control {
    min-height: 44px;
    font-size: 16px; /* Previne zoom no iOS */
  }
}
```

---

## Design Decisions

### 1. Por que Vanilla JS?
- ✅ Sem dependências pesadas
- ✅ Performance máxima
- ✅ Fácil manutenção
- ✅ Bundle size mínimo
- ⚠️ Migrar para React/Vue na Fase 3 se necessário

### 2. Por que localStorage?
- ✅ Funciona offline
- ✅ Sem necessidade de backend para MVP
- ✅ Rápido e simples
- ⚠️ Migrar para Supabase na Fase 2

### 3. Por que GPT-4o-mini?
- ✅ Custo baixo ($0.15/1M tokens)
- ✅ Velocidade adequada (2-5s)
- ✅ Qualidade suficiente para MVP
- ⚠️ Considerar fine-tuning na Fase 3

### 4. Por que html2pdf.js?
- ✅ Funciona no cliente
- ✅ Sem necessidade de backend
- ✅ Fácil implementação
- ⚠️ Migrar para Puppeteer (backend) na Fase 2 para melhor qualidade

---

## Migration Path

### Fase 1 → Fase 2
```javascript
// localStorage → Supabase
async function migrateToCloud() {
  const localData = localStorage.getItem('procv-data');
  if (localData) {
    const { data, error } = await supabase
      .from('cvs')
      .insert([JSON.parse(localData)]);
    
    if (!error) {
      localStorage.removeItem('procv-data');
      showToast('✅ Dados migrados para nuvem!');
    }
  }
}
```

### Fase 2 → Fase 3
```javascript
// Adicionar planos
const user = {
  ...existingUser,
  plan: 'free' | 'premium',
  subscription: {
    status: 'active' | 'canceled',
    currentPeriodEnd: timestamp,
    stripeCustomerId: string
  }
};
```

---

## API Rate Limits

### Free Tier (MVP)
- 100 requisições / 15 minutos
- 5 análises completas / dia
- 10 adaptações de vaga / dia

### Premium (Fase 3)
- Ilimitado
- Prioridade nas filas
- Modelos avançados

---

## Success Criteria

### Technical
- ✅ 99% uptime
- ✅ < 2s load time
- ✅ < 5s IA response
- ✅ 0 critical bugs
- ✅ Mobile score > 90 (Lighthouse)

### Business
- ✅ 100 usuários em 4 semanas
- ✅ 50 CVs criados
- ✅ 500 usos de IA
- ✅ NPS > 40
- ✅ Taxa de conclusão > 60%

---

**Versão:** 1.0  
**Data:** 28 de Outubro de 2024  
**Status:** ✅ Aprovado para Implementation Planning
